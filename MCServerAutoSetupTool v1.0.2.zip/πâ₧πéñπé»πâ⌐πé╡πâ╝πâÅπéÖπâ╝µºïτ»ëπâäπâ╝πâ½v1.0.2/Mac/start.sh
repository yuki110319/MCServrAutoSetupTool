#!/usr/bin/env bash 

echo "[MCSAST] Server Start"
java -Xmx3G -jar spigot-1.18.2.jar nogui