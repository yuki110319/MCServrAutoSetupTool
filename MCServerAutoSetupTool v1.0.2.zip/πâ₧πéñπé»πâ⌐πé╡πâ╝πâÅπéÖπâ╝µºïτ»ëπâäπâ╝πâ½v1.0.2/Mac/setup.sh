#!/usr/bin/env bash 

echo "MCServerAutoSetupTool v1.0.2 Beta"
echo "#※実行した時点でMCServerAutoSetupToolとMojangのEULAに同意したことになります"
read -p "input? > " str	
case "$str" in			
  [Yy]|[Yy][Ee][Ss])
    echo "YES"
    echo "OK"
    ;;
  [Nn]|[Nn][Oo])
    echo "NO"
    ;;
  *)
    echo "undefined";;
esac
curl -O https://download.getbukkit.org/spigot/spigot-1.18.2.jar
echo "初回起動します"
java -Xmx1G -jar spigot-1.18.2.jar nogui
sed -i -e "s/false/true/g" eula.txt
java -Xmx1G -jar spigot-1.18.2.jar nogui
stop
echo "Setupが完了しました 2回目以降の起動は./setup.sh"