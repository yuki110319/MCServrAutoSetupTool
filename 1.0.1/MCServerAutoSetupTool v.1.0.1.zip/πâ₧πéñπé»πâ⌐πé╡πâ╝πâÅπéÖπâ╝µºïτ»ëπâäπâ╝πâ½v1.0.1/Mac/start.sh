#!/usr/bin/env bash 

java -Xmx3G -jar spigot-1.18.2.jar nogui