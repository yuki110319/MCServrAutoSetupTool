#!/usr/bin/env bash 

java -Xmx3G -jar paper-1.18.2-329.jar nogui