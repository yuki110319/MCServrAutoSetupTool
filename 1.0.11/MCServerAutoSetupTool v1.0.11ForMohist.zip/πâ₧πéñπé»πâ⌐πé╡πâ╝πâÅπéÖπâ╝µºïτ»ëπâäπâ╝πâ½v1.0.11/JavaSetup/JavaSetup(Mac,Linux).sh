#!/usr/bin/env bash 

sudo apt install openjdk-8-jre -y