#!/usr/bin/env bash 

sudo apt install open-jdk-8-jre -y
curl -O https://papermc.io/api/v2/projects/paper/versions/1.18.2/builds/329/downloads/paper-1.18.2-329.jar
java -Xmx3G -jar paper-1.18.2-329.jar nogui