#!/usr/bin/env bash 

wget  https://download.getbukkit.org/spigot/spigot-1.18.2.jar
java -Xmx3G -jar spigot-1.18.2.jar nogui