#!/usr/bin/env bash 

sudo apt install openjdk-17-jre -y